from flask import Flask, render_template, url_for, redirect, request
from flask_mysqldb import MySQL,MySQLdb

app=Flask(__name__,instance_relative_config=True)
mysql=MySQLdb.connect(user='random',db='todo')


def insert_todo(name,todo):
    cur=mysql.cursor()
    cur.execute("insert into user_record(name,todo) values (%s,%s)",(name,todo))
    mysql.commit()
    cur.close()
    return

def get_todo(name):
    cur=mysql.cursor()
    todos=cur.execute("select name,todo from user_record where name=(%s)",(name,))
    todos_val=cur.fetchall()
    cur.close()
    return todos_val


@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')


@app.route('/view_todo', methods=['GET'])
def display_todo():
    name=request.form.get('name')
    todo=request.form.get('todo')
    if todo==None and name==None:
        return render_template('alert.html', msg='Enter A Name To View TODO') 
    elif todo==None and name!=None:
        return render_template('todo_view.html', todos=get_todo(name))
    else:
        insert_todo(name,todo)
        return render_template('todo_view.html',todos=get_todo(name))

@app.route('/clear')
def clear():
    cur=mysql.cursor()
    cur.execute("truncate table user_record")
    cur.close()
    return render_template('home.html')

@app.route('/add_todo',methods=['POST'])
def add_todo():
    name=request.form.get('name')
    todo=request.form.get('todo')
    insert_todo(name,todo)
    return render_template('todo_view.html', todos=get_todo(name))
